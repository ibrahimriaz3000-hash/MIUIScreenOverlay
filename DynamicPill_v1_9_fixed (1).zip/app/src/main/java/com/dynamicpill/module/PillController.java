package com.dynamicpill.module;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/** Adds the pill as an always-on overlay window inside the System UI process. */
public class PillController {
    static final String MODULE_PKG = "com.dynamicpill.module";
    static final String PREF_FILE = "pill_prefs";
    static final String K_ENABLED = "enabled";
    static final String K_WIDTH = "width_mm10";     // 0.1 mm units
    static final String K_HEIGHT = "height_mm10";   // 0.1 mm units
    static final String K_YOFF = "yoff_mm10";       // 0.1 mm units, can be negative
    static final String K_ALPHA = "alpha_pct";
    // iOS style line (grabber) under the status bar
    static final String K_LINE_ON = "line_on";
    static final String K_LINE_W = "line_w2_mm10";
    static final String K_LINE_H = "line_h_mm10";
    static final String K_LINE_X = "line_right_mm10"; // distance from right edge to line CENTER
    static final String K_LINE_Y = "line_top_mm10";   // distance from top of screen
    static final String K_LINE_ALPHA = "line_alpha_pct";
    static final int D_LINE_W = 160, D_LINE_X = 125, D_LINE_Y = 69;
    static final String K_BORDER = "border_mm10"; // 0 = off
    static final String K_LOCK = "show_lock";
    // indicators inside the pill
    static final String K_IND_DOT = "ind_dot";
    static final String K_IND_WA = "ind_whatsapp";
    static final String K_IND_CALL = "ind_call";
    static final String K_IND_CHARGE = "ind_charge";
    static final String K_IND_NOTIF = "ind_notif";
    /** How long the dot keeps blinking after a notification arrives. */
    static final long NOTIF_BLINK_MS = 15000;
    static final String K_PAD_L = "pad_l_mm10";
    static final String K_PAD_R = "pad_r_mm10";
    static final String K_PAD_T = "pad_t_mm10";
    static final int D_WIDTH = 135;                  // 13.5 mm
    static final int D_HEIGHT = 40;                  // 4.0 mm
    static final int D_YOFF = 0;

    private static java.lang.ref.WeakReference<View> barContents, barRoot;
    private static int[] origContents, origRoot;
    // Top padding = extra status bar height (so icons move down instead of getting squashed/clipped)
    private static volatile int extraTop = 0;
    private static final java.util.HashMap<Integer, Boolean> heightIds = new java.util.HashMap<>();
    private static java.lang.ref.WeakReference<Object> sbWindowController;

    private static boolean isBarHeightId(android.content.res.Resources r, int id) {
        if (id == 0) return false;
        synchronized (heightIds) {
            Boolean b = heightIds.get(id);
            if (b != null) return b;
        }
        boolean m = false;
        try {
            String n = r.getResourceEntryName(id);
            m = "status_bar_height".equals(n) || "status_bar_height_portrait".equals(n)
                    || "status_bar_height_landscape".equals(n) || "status_bar_height_default".equals(n);
        } catch (Throwable ignored) { }
        synchronized (heightIds) { heightIds.put(id, m); }
        return m;
    }

    /** Makes the status bar taller by the "Top" padding value. */
    static void hookStatusBarHeight(ClassLoader cl) {
        de.robv.android.xposed.XC_MethodHook h = new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                int extra = extraTop;
                if (extra <= 0) return;
                try {
                    if (!isBarHeightId((android.content.res.Resources) param.thisObject,
                            (Integer) param.args[0])) return;
                    Object res = param.getResult();
                    if (res instanceof Integer) param.setResult((Integer) res + extra);
                    else if (res instanceof Float) param.setResult((Float) res + extra);
                } catch (Throwable ignored) { }
            }
        };
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimensionPixelSize", int.class, h);
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimensionPixelOffset", int.class, h);
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimension", int.class, h);

        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.window.StatusBarWindowController", cl);
        if (c != null) {
            XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    sbWindowController = new java.lang.ref.WeakReference<>(param.thisObject);
                }
            });
        }
    }

    private void refreshBarHeight() {
        Object o = sbWindowController == null ? null : sbWindowController.get();
        if (o == null) return;
        try {
            de.robv.android.xposed.XposedHelpers.callMethod(o, "refreshStatusBarHeight");
        } catch (Throwable ignored) { }
    }

    private static java.lang.ref.WeakReference<Object> kgManager;

    /** Captures the keyguard view manager so we can ask whether the PIN/pattern screen is showing. */
    static void hookKeyguardManager(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.phone.StatusBarKeyguardViewManager", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                kgManager = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    private static java.lang.ref.WeakReference<Object> sbState;

    static void hookStatusBarState(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.StatusBarStateControllerImpl", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                sbState = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    /** AOSP states: 0 = shade (unlocked), 1 = keyguard, 2 = shade over keyguard. */
    private int barState() {
        Object o = sbState == null ? null : sbState.get();
        if (o == null) return -1;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, "getState");
            if (r instanceof Integer) return (Integer) r;
        } catch (Throwable ignored) { }
        return -1;
    }

    private static java.lang.ref.WeakReference<Object> shadeWin;

    static void hookShadeWindow(ClassLoader cl) {
        String[] names = {
                "com.android.systemui.statusbar.NotificationShadeWindowControllerImpl",
                "com.android.systemui.statusbar.phone.NotificationShadeWindowControllerImpl"
        };
        for (String n : names) {
            Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(n, cl);
            if (c == null) continue;
            XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    shadeWin = new java.lang.ref.WeakReference<>(param.thisObject);
                }
            });
        }
    }

    private Boolean pollBool(java.lang.ref.WeakReference<Object> ref, String name) {
        Object o = ref == null ? null : ref.get();
        if (o == null) return null;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, name);
            if (r instanceof Boolean) return (Boolean) r;
        } catch (Throwable ignored) { }
        return null;
    }

    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> ccViews = new java.util.ArrayList<>();
    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> bouncerViews = new java.util.ArrayList<>();

    private static void track(java.util.ArrayList<java.lang.ref.WeakReference<View>> list, View v) {
        synchronized (list) {
            for (int i = list.size() - 1; i >= 0; i--) {
                View o = list.get(i).get();
                if (o == null) list.remove(i);
                else if (o == v) return;
            }
            if (list.size() < 24) list.add(new java.lang.ref.WeakReference<>(v));
        }
    }

    /** Remembers Control Center views (class name contains "ControlCenter"). */
    static void registerControlCenter(View v) { track(ccViews, v); }

    /** Remembers PIN / pattern (bouncer) views. */
    static void registerBouncer(View v) { track(bouncerViews, v); }

    private float effectiveAlpha(View v) {
        float a = 1f;
        View c = v;
        for (int i = 0; i < 12 && c != null; i++) {
            a *= c.getAlpha();
            c = (c.getParent() instanceof View) ? (View) c.getParent() : null;
        }
        return a;
    }

    /** True while one of the tracked views is really visible and covers at least minFraction of the screen height. */
    private boolean anyVisible(java.util.ArrayList<java.lang.ref.WeakReference<View>> list,
                               float minFraction, float minAlpha) {
        int screenH = wm.getCurrentWindowMetrics().getBounds().height();
        android.graphics.Rect r = new android.graphics.Rect();
        synchronized (list) {
            for (int i = list.size() - 1; i >= 0; i--) {
                View v = list.get(i).get();
                if (v == null) { list.remove(i); continue; }
                try {
                    if (!v.isAttachedToWindow() || !v.isShown()
                            || v.getWindowVisibility() != View.VISIBLE) continue;
                    if (effectiveAlpha(v) < minAlpha) continue;
                    if (!v.getGlobalVisibleRect(r)) continue;
                    if (r.height() > screenH * minFraction) return true;
                } catch (Throwable ignored) { }
            }
        }
        return false;
    }

    private boolean controlCenterOpen() { return anyVisible(ccViews, 0.3f, 0.05f); }

    /** PIN / pattern screen showing or being swiped up. */
    private boolean pinScreenOpen() {
        boolean b = false;
        try { b = bouncerShowing(); } catch (Throwable ignored) { }
        return b || anyVisible(bouncerViews, 0.08f, 0.02f);
    }

    /** True while the notification shade / Control Center is pulled down (best effort). */
    private boolean panelExpanded() {
        Boolean a = pollBool(sbState, "isExpanded");
        Boolean b = pollBool(shadeWin, "getPanelExpanded");
        Boolean c = pollBool(shadeWin, "isPanelExpanded");
        return (a != null && a) || (b != null && b) || (c != null && c);
    }

    private String lastLineLog = "";

    private boolean bouncerShowing() {
        Object o = kgManager == null ? null : kgManager.get();
        if (o == null) return false;
        String[] names = {"isBouncerShowing", "primaryBouncerIsShowing",
                "isPrimaryBouncerShowing", "bouncerIsShowing"};
        for (String n : names) {
            try {
                Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, n);
                if (r instanceof Boolean) return (Boolean) r;
            } catch (Throwable ignored) { }
        }
        return false;
    }

    // ---- notification blink: every StatusBarNotification System UI receives passes through here
    private static volatile long notifBlinkUntil = 0;
    private static String lastNotifKey = "";
    private static long lastNotifAt = 0;

    static void hookNotifications() {
        XposedBridge.hookAllConstructors(android.service.notification.StatusBarNotification.class,
                new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    android.service.notification.StatusBarNotification sbn =
                            (android.service.notification.StatusBarNotification) param.thisObject;
                    android.app.Notification n = sbn.getNotification();
                    if (n == null) return;
                    int skip = android.app.Notification.FLAG_ONGOING_EVENT
                            | android.app.Notification.FLAG_FOREGROUND_SERVICE
                            | android.app.Notification.FLAG_GROUP_SUMMARY;
                    if ((n.flags & skip) != 0) return;
                    // only fresh notifications (not the old list System UI receives at boot / on removal)
                    if (System.currentTimeMillis() - sbn.getPostTime() > 5000) return;
                    String key = sbn.getKey();
                    long now = android.os.SystemClock.uptimeMillis();
                    if (key != null && key.equals(lastNotifKey) && now - lastNotifAt < 2000) return;
                    lastNotifKey = key == null ? "" : key;
                    lastNotifAt = now;
                    notifBlinkUntil = now + NOTIF_BLINK_MS;
                } catch (Throwable ignored) { }
            }
        });
    }

    /** Phone call ringing / ongoing, or a VoIP call (WhatsApp etc.) using the call audio mode. */
    @SuppressWarnings("deprecation")
    private boolean callActive() {
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager)
                    ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null && tm.getCallState() != android.telephony.TelephonyManager.CALL_STATE_IDLE) return true;
        } catch (Throwable ignored) { }
        try {
            android.media.AudioManager am = (android.media.AudioManager)
                    ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int m = am.getMode();
                return m == android.media.AudioManager.MODE_IN_CALL
                        || m == android.media.AudioManager.MODE_IN_COMMUNICATION
                        || m == android.media.AudioManager.MODE_RINGTONE;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private long lastWaCheck = 0;
    private boolean cachedWa = false;

    /** True while WhatsApp (or WhatsApp Business) is the top app. */
    @SuppressWarnings("deprecation")
    private boolean isWhatsAppForeground() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastWaCheck < 700) return cachedWa;
        lastWaCheck = now;
        try {
            android.app.ActivityManager am = (android.app.ActivityManager)
                    ctx.getSystemService(Context.ACTIVITY_SERVICE);
            java.util.List<android.app.ActivityManager.RunningTaskInfo> t = am.getRunningTasks(1);
            if (t != null && !t.isEmpty() && t.get(0).topActivity != null) {
                String pkg = t.get(0).topActivity.getPackageName();
                cachedWa = "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg);
            } else {
                cachedWa = false;
            }
        } catch (Throwable e) {
            cachedWa = false;
        }
        return cachedWa;
    }

    static void registerBar(View v, boolean contents) {
        // If the same view attaches again its padding already includes our extra padding,
        // so keep the original numbers instead of recording them a second time.
        View cur = contents ? (barContents == null ? null : barContents.get())
                            : (barRoot == null ? null : barRoot.get());
        if (cur == v) return;
        int[] o = {v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), v.getPaddingBottom()};
        if (contents) { barContents = new java.lang.ref.WeakReference<>(v); origContents = o; }
        else { barRoot = new java.lang.ref.WeakReference<>(v); origRoot = o; }
    }

    private void applyBarPadding() {
        View v = null; int[] o = null;
        if (barContents != null && barContents.get() != null) { v = barContents.get(); o = origContents; }
        else if (barRoot != null && barRoot.get() != null) { v = barRoot.get(); o = origRoot; }
        if (v == null || o == null) return;
        int l = o[0] + mm(pref(K_PAD_L, 0));
        int t = o[1] + mm(pref(K_PAD_T, 0));
        int r = o[2] + mm(pref(K_PAD_R, 0));
        if (v.getPaddingLeft() != l || v.getPaddingTop() != t || v.getPaddingRight() != r) {
            v.setPadding(l, t, r, o[3]);
        }
    }

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final WindowManager wm;
    private XSharedPreferences xsp;
    private PillView view;
    private LineView lineView;
    private boolean lineAdded = false;
    private boolean lastLineVisible = true;
    private int lastLW = -1, lastLH = -1, lastLX = Integer.MIN_VALUE, lastLY = Integer.MIN_VALUE;
    private boolean added = false;
    private int lastW = -1, lastH = -1, lastY = Integer.MIN_VALUE;
    private boolean lastVisible = true;
    private int winType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    // lockscreen ke upar dikhne wale system window types (pehle wala chalega jo allow ho)
    private static final int[] TYPES = {
            2017, // TYPE_STATUS_BAR_SUB_PANEL
            2024, // TYPE_NAVIGATION_BAR_PANEL
            2038  // TYPE_APPLICATION_OVERLAY (fallback)
    };

    public PillController(Context ctx) {
        this.ctx = ctx;
        this.wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    public void start() {
        try {
            xsp = new XSharedPreferences(MODULE_PKG, PREF_FILE);
            xsp.makeWorldReadable();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: prefs init: " + t);
        }
        try { extraTop = mm(pref(K_PAD_T, 0)); } catch (Throwable ignored) { }
        // small delay so System UI finishes booting
        handler.postDelayed(tick, 4000);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                update();
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: update failed: " + t);
            }
            handler.postDelayed(this, 400);
        }
    };

    private int pref(String key, int def) {
        try {
            if (xsp != null) return xsp.getInt(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private boolean prefBool(String key, boolean def) {
        try {
            if (xsp != null) return xsp.getBoolean(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private int mm(float mm10) {
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_MM, mm10 / 10f, dm));
    }

    private int cutoutCenterY() {
        try {
            DisplayCutout dc = wm.getCurrentWindowMetrics().getWindowInsets().getDisplayCutout();
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) return (r.top + r.bottom) / 2;
            }
        } catch (Throwable ignored) { }
        try {
            android.hardware.display.DisplayManager dmg = (android.hardware.display.DisplayManager)
                    ctx.getSystemService(Context.DISPLAY_SERVICE);
            android.view.Display d = dmg == null ? null : dmg.getDisplay(android.view.Display.DEFAULT_DISPLAY);
            DisplayCutout dc = d == null ? null : d.getCutout();
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) return (r.top + r.bottom) / 2;
            }
        } catch (Throwable ignored) { }
        try {
            int id = ctx.getResources().getIdentifier("status_bar_height", "dimen", "android");
            // our status bar height hook adds the "Top" padding; take it out so the pill stays on the camera
            if (id > 0) return Math.max(0, ctx.getResources().getDimensionPixelSize(id) - extraTop) / 2;
        } catch (Throwable ignored) { }
        return mm(30);
    }

    // ---- charging / power saving colours
    private static final int COLOR_WHITE = 0xFFFFFFFF;
    private static final int COLOR_GREEN = 0xFF34C759;
    private static final int COLOR_YELLOW = 0xFFFFCC00;
    private boolean charging = false, powerSave = false;
    private long lastPowerCheck = 0;

    private void refreshPower() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastPowerCheck < 1000) return;
        lastPowerCheck = now;
        try {
            android.content.Intent i = ctx.registerReceiver(null,
                    new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
            charging = i != null && i.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
        } catch (Throwable ignored) { }
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            powerSave = pm != null && pm.isPowerSaveMode();
        } catch (Throwable ignored) { }
    }

    private int lineColor() {
        return charging ? COLOR_GREEN : (powerSave ? COLOR_YELLOW : COLOR_WHITE);
    }

    private void update() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (added && pm != null && !pm.isInteractive()) { // screen off: nothing to update
                if (view != null) { view.setBlink(false); view.setStrokeBlink(false); }
                return;
            }
        } catch (Throwable ignored) { }
        if (xsp != null && xsp.hasFileChanged()) xsp.reload();
        refreshPower();
        final boolean call = prefBool(K_IND_CALL, true) && callActive();

        try {
            int e = mm(pref(K_PAD_T, 0));
            if (e != extraTop) {
                extraTop = e;
                refreshBarHeight();
            }
        } catch (Throwable ignored) { }
        try { applyBarPadding(); } catch (Throwable ignored) { }

        boolean enabled = prefBool(K_ENABLED, true);
        boolean portrait = ctx.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_PORTRAIT;
        boolean locked = false;
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager)
                    ctx.getSystemService(Context.KEYGUARD_SERVICE);
            locked = km != null && km.isKeyguardLocked();
        } catch (Throwable ignored) { }
        boolean visible = enabled && portrait && (!locked || prefBool(K_LOCK, true));

        int w = mm(pref(K_WIDTH, D_WIDTH));
        int h = mm(pref(K_HEIGHT, D_HEIGHT));
        int y = cutoutCenterY() - h / 2 + mm(pref(K_YOFF, D_YOFF));

        if (!added) {
            view = new PillView(ctx);
            for (int type : TYPES) {
                try {
                    wm.addView(view, params(w, h, y, type));
                    winType = type;
                    added = true;
                    break;
                } catch (Throwable t) {
                    XposedBridge.log("DynamicPill: window type " + type + " failed: " + t);
                    view = new PillView(ctx);
                }
            }
            if (!added) return;
            lastW = w; lastH = h; lastY = y;
        } else if (w != lastW || h != lastH || y != lastY) {
            wm.updateViewLayout(view, params(w, h, y, winType));
            lastW = w; lastH = h; lastY = y;
        }

        try { view.setPillAlpha(pref(K_ALPHA, 100)); } catch (Throwable ignored) { }
        try {
            int bw = mm(pref(K_BORDER, 4));
            if ((charging || call) && bw < 1) bw = Math.round(ctx.getResources().getDisplayMetrics().density * 3f);
            view.setBorder(bw);
            // call or charging = green outline (a call also makes it blink)
            view.setStrokeColor((call || charging) ? COLOR_GREEN : COLOR_WHITE);
            view.setStrokeBlink(call);
        } catch (Throwable ignored) { }

        try {
            boolean dotOn = prefBool(K_IND_DOT, true);
            boolean wa = dotOn && prefBool(K_IND_WA, true) && !locked && isWhatsAppForeground();
            view.setDot(dotOn, wa ? COLOR_YELLOW : COLOR_WHITE);
            view.setBolt(charging && prefBool(K_IND_CHARGE, true));
            boolean blink = dotOn && prefBool(K_IND_NOTIF, true)
                    && android.os.SystemClock.uptimeMillis() < notifBlinkUntil;
            // user pulled the shade down = notification seen (on the lock screen "expanded" is always true,
            // so there we use the "shade over keyguard" state instead, same as the line does)
            if (blink && (locked ? barState() == 2 : panelExpanded())) {
                notifBlinkUntil = 0;
                blink = false;
            }
            view.setBlink(blink);
        } catch (Throwable ignored) { }

        if (visible != lastVisible) {
            view.setVisibility(visible ? View.VISIBLE : View.GONE);
            lastVisible = visible;
        }

        try {
            updateLine(portrait, locked);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: line failed: " + t);
        }
    }

    private void updateLine(boolean portrait, boolean locked) {
        // Lock screen: shown, but hidden on the PIN / pattern screen (also while swiping it up)
        // and while the shade / Control Center is pulled over it.
        // Unlocked (home + apps): shown, hidden while the shade / Control Center is open.
        boolean hide = false;
        try {
            if (locked) hide = pinScreenOpen() || barState() == 2 || controlCenterOpen();
            else hide = panelExpanded() || controlCenterOpen();
        } catch (Throwable ignored) { }
        boolean expanded = hide;
        boolean on = prefBool(K_LINE_ON, true) && portrait && !hide;
        String why = "on=" + on + " locked=" + locked + " expanded=" + expanded;
        if (!why.equals(lastLineLog)) {
            lastLineLog = why;
            XposedBridge.log("DynamicPill: line " + why);
        }
        int w = mm(pref(K_LINE_W, D_LINE_W));
        int h = Math.max(1, mm(pref(K_LINE_H, 6)));
        int fromRight = mm(pref(K_LINE_X, D_LINE_X));
        int top = mm(pref(K_LINE_Y, D_LINE_Y));
        int alpha = pref(K_LINE_ALPHA, 70);

        // The line is an overlay window (hosting it inside the keyguard view was invisible on some ROMs).
        boolean vis = on;
        int x = Math.max(0, fromRight - w / 2);
        if (!lineAdded) {
            lineView = new LineView(ctx);
            wm.addView(lineView, lineParams(w, h, x, top, winType));
            lineAdded = true;
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
            lineView.setShown(vis);
            lastLineVisible = vis;
        } else if (w != lastLW || h != lastLH || x != lastLX || top != lastLY) {
            wm.updateViewLayout(lineView, lineParams(w, h, x, top, winType));
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
        }
        lineView.setLineAlpha(alpha);
        lineView.setTint(lineColor());
        if (vis != lastLineVisible) {
            lineView.setShown(vis);
            lastLineVisible = vis;
        }
    }

    private WindowManager.LayoutParams lineParams(int w, int h, int x, int y, int type) {
        WindowManager.LayoutParams lp = params(w, h, y, type);
        lp.gravity = Gravity.TOP | Gravity.END;   // x = distance from the right edge
        lp.x = x;
        lp.setTitle("DynamicPillLine");
        return lp;
    }

    private WindowManager.LayoutParams params(int w, int h, int y, int type) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.x = 0;
        lp.y = y;
        lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.alpha = 1.0f; // window alpha poora solid
        lp.setTitle("DynamicPill");
        return lp;
    }
}
